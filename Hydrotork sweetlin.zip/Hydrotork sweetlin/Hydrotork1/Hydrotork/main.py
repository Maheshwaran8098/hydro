from flask import Flask, request, render_template,redirect,jsonify
import smtplib
from email.mime.text import MIMEText
from flask import*
from dotenv import load_dotenv
import os


app = Flask(__name__)

@app.route("/")
def show_form():
    print("11")
    return render_template("index.html")

@app.route("/index")
def index():
    print("index")
    return redirect (url_for("show_form"))

@app.route("/indexSection")
def indexSection():
    print("indexSection")
    return render_template ("index.html")

@app.route("/about")
def about():
    print("about")
    return render_template ("about.html")
@app.route("/pro")
def pro():
    print("pro")
    return render_template("products.html")
@app.route("/indus")
def indus():
    print("industries")
    return render_template("industries.html")
@app.route("/contactSection")
def contactSection():
    print("contact")
    return render_template ("index.html")





@app.route("/productSection")
def productSection():
    print("productSection")
    return render_template("products.html")
@app.route("/aboutSection")
def aboutSection():
    print("aboutSection")
    return render_template("about.html")
@app.route("/industriesSection")
def industriesSection():
    print("industriesSection")
    return render_template("industries.html")


# about
@app.route("/abtStrategy")
def abtStrategy():
    print("abtStrategy")
    return render_template("strategy.html")
@app.route("/abtHistory")
def abtHistory():
    print("abtHistory")
    return render_template("history.html")
@app.route("/abtProducts")
def abtProducts():
    print("abtProducts")
    return render_template("products.html")
@app.route("/abtLocation")
def abtLocation():
    print("abtLocation")
    return render_template("locations.html")


# products
@app.route("/product1")
def product1():
    print("productPumps")
    return render_template("produ1.html")
@app.route("/product2")
def product2():
    print("productValves")
    return render_template("produ2.html")
@app.route("/product3")
def product3():
    print("productPower")
    return render_template("produ3.html")
@app.route("/product4")
def product4():
    print("productPower")
    return render_template("produ4.html")
@app.route("/product5")
def product5():
    print("Intersial Valves")
    return render_template("produ5.html")
@app.route("/product6")
def product6():
    print("Control Works")
    return render_template("produ6.html")
@app.route("/product7")
def product7():
    print("Activation")
    return render_template("produ7.html")
@app.route("/product8")
def product8():
    print("Directional control")
    return render_template("produ8.html")
@app.route("/product9")
def product9():
    print("Throttle valve")
    return render_template("produ9.html")
@app.route("/product10")
def product10():
    print("PVR1T Variable")
    return render_template("produ10.html")
@app.route("/product11")
def product11():
    print("HPV43 Double")
    return render_template("produ11.html")
@app.route("/product12")
def product12():
    print("Cartridge Valve")
    return render_template("produ12.html")

@app.route("/log")
def log():
    return render_template("form.html")



@app.route("/senw", methods=['POST', "GET"])
def senw():
    
    name=request.form.get("name") 
    a=name
    whatnum=request.form.get("whatnum")
    b=whatnum
    
    c= [" ","A", "B", "C", "D", "E", "F", "G", "H", "I", ".","J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z","a", "b", "c", "d", "e", "f", "g", "h", "i",'j',"k" "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    d=['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'] 
    e=len(a)
    
    f=len(b)
    

    if e>0 :
        
        if all(i in c for i in a) :
                        
            if f==10:
                    if all(i in d for i in b):
                        mail="youremail@gmail.com"
                        password="your password"

                        tomail="ramraja.e99@gmail.com"

                        # Create email message
                        msg = MIMEText(b)
                        msg['Subject']=a
                        msg['From'] =mail 
                        msg['To'] =tomail
                        try:
                            # Enable security for Gmail (use port 587)
                            server = smtplib.SMTP('smtp.gmail.com', 587)
                            server.starttls()
                            # server.login(request.form.get("fmail"), password) 
                            
                            server.login(mail, password)
                            
                            server.sendmail(msg['From'],msg['To'],msg.as_string())
                            server.quit()
                            print("sucefully")
                            return jsonify({"status": "error", "message": "message send sucessfully"})

                            
                        except Exception as e:
                            return f"Failed to send email: {e}"
                                                  
            else:
                  print("please enter the 10 digit mobil number")
                  return jsonify({"status": "error", "message": "Please enter a valid 10-digit phone numbers"})
                
        else:
              print("name is not  allowed the any numbers & spl charactors")
              return jsonify({"status": "error", "message": "Please Enter Your Name"})
      
            
    else:
        print(" first fill the name")
        return jsonify({"status": "error", "message": "Please enter a the correct name"})
        
                


if __name__ == "__main__":
    app.run(debug=True)


